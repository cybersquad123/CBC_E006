# **App Name**: WanderGenie

## Core Features:

- Smart Itinerary Generator: AI-powered suggestion tool: Generates a travel itinerary based on user preferences for offbeat and underrated destinations. Uses current travel data to provide accurate info.
- Interactive Map: Interactive Map: Displays suggested locations on an interactive map for easy visualization.
- Destination Info: Destination Information Display: Shows key details about each location, including brief descriptions, points of interest, and travel tips.
- Preference Input: Preference Input: Allows users to input travel preferences such as trip length, interests (e.g., hiking, food, history), and budget.

## Style Guidelines:

- Primary color: Earthy green (#386641) for a natural, adventurous feel.
- Secondary colors: Warm beige (#E3D5CA) and soft brown (#6F613F).
- Accent: Terracotta (#BC6C25) for CTAs and highlights.
- Clean, sans-serif fonts for easy readability.
- Simple, line-based icons for a modern, uncluttered look.
- Card-based design for presenting destinations, ensuring a clean and organized user experience.