
// src/app/page.tsx (New Landing Page)
"use client";

import Link from 'next/link';
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { AppHeader } from '@/components/wander-genie/AppHeader';
import { useAuth } from '@/contexts/AuthContext';
import { ArrowRight, Compass, Users, MapPin } from 'lucide-react';

export default function LandingPage() {
  const { user, loading } = useAuth();

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-background to-muted/50 text-foreground">
      <AppHeader />
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-20 md:py-32 bg-primary/10">
          <div className="container mx-auto px-4 text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-primary mb-6">
              Discover Your Next Adventure with WanderGenie
            </h1>
            <p className="text-lg md:text-xl text-foreground/80 max-w-3xl mx-auto mb-10">
              Tired of the usual tourist traps? Let our AI craft personalized travel plans to offbeat and underrated destinations, tailored to your unique interests and budget.
            </p>
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground shadow-lg">
              <Link href={user ? "/planner" : "/login"}>
                {loading ? 'Loading...' : (user ? 'Go to Planner' : 'Get Started')}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
            <div className="mt-16 max-w-4xl mx-auto">
              <Image
                src="https://picsum.photos/seed/landinghero/1200/600"
                alt="Inspiring travel collage"
                width={1200}
                height={600}
                className="rounded-xl shadow-2xl object-cover"
                data-ai-hint="travel collage adventure"
                priority
              />
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="py-16 md:py-24 bg-background">
          <div className="container mx-auto px-4">
            <h2 className="text-3xl md:text-4xl font-bold text-center text-primary mb-16">How WanderGenie Works</h2>
            <div className="grid md:grid-cols-3 gap-8 md:gap-12">
              <div className="flex flex-col items-center text-center p-6 bg-card rounded-lg shadow-lg border border-primary/10">
                <Compass className="h-16 w-16 text-accent mb-6" />
                <h3 className="text-2xl font-semibold text-foreground mb-3">1. Share Your Preferences</h3>
                <p className="text-muted-foreground">
                  Tell us about your dream trip – duration, interests, budget, food preferences, and any location ideas.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 bg-card rounded-lg shadow-lg border border-primary/10">
                <Users className="h-16 w-16 text-accent mb-6" />
                <h3 className="text-2xl font-semibold text-foreground mb-3">2. Get AI-Powered Options</h3>
                <p className="text-muted-foreground">
                  Our intelligent AI generates unique travel plan options, focusing on hidden gems and underrated spots.
                </p>
              </div>
              <div className="flex flex-col items-center text-center p-6 bg-card rounded-lg shadow-lg border border-primary/10">
                <MapPin className="h-16 w-16 text-accent mb-6" />
                <h3 className="text-2xl font-semibold text-foreground mb-3">3. Explore Detailed Itineraries</h3>
                <p className="text-muted-foreground">
                  Choose your favorite plan and receive a day-by-day itinerary, ready for your adventure.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* Call to Action Section */}
        <section className="py-16 md:py-24 bg-primary/5">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-primary mb-6">Ready to Uncover the Unseen?</h2>
            <p className="text-lg text-foreground/80 max-w-2xl mx-auto mb-10">
              Sign up or log in to start planning your extraordinary journey with WanderGenie.
            </p>
            <Button asChild size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground shadow-lg">
              <Link href={user ? "/planner" : "/login"}>
                 {loading ? 'Loading...' : (user ? 'Go to Planner' : 'Start Your Adventure')}
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </section>
      </main>
      <footer className="text-center py-6 px-4 text-sm text-muted-foreground border-t border-border/50 bg-background/80">
        WanderGenie &copy; {new Date().getFullYear()} - Your AI Companion for Offbeat Adventures.
      </footer>
    </div>
  );
}
