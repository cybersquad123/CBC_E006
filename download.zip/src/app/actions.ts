// src/app/actions.ts
"use server";

import { z } from 'zod';
import { 
  generateTravelPlanOptions, 
  type GenerateTravelPlanOptionsInput,
  type TravelPlanOption 
} from '@/ai/flows/generate-travel-plan-options';
import { 
  elaborateSelectedPlan, 
  type ElaborateSelectedPlanInput,
  type ElaborateSelectedPlanOutput
} from '@/ai/flows/elaborate-selected-plan';

// Schema for initial preference input validation
const PreferenceSchema = z.object({
  duration: z.string().min(1, "Duration is required."),
  interests: z.string().min(1, "Interests are required."),
  foodPreference: z.string().optional(), // Added foodPreference
  budget: z.enum(["Low", "Medium", "High"], { required_error: "Budget is required."}),
  country: z.string().optional(),
  city: z.string().optional(),
});
export type OriginalPreferences = z.infer<typeof PreferenceSchema>;

// State for the options generation form
export type OptionsFormState = {
  status: 'initial' | 'pending' | 'success' | 'error';
  options?: TravelPlanOption[];
  originalPreferences?: OriginalPreferences; 
  error?: string | null;
  fieldErrors?: z.ZodError<GenerateTravelPlanOptionsInput>['formErrors']['fieldErrors'];
};

// State for the plan elaboration form/action
export type ElaborationFormState = {
  status: 'initial' | 'pending' | 'success' | 'error';
  detailedItinerary?: ElaborateSelectedPlanOutput; 
  error?: string | null;
  fieldErrors?: Record<string, string[]>; 
};


export async function generateOptionsAction(
  prevState: OptionsFormState, 
  formData: FormData
): Promise<OptionsFormState> {
  const rawData = {
    duration: formData.get('duration') as string,
    interests: formData.get('interests') as string,
    foodPreference: formData.get('foodPreference') as string | undefined, // Added foodPreference
    budget: formData.get('budget') as string,
    country: formData.get('country') as string | undefined,
    city: formData.get('city') as string | undefined,
  };

  const validatedFields = PreferenceSchema.safeParse(rawData);

  if (!validatedFields.success) {
    return {
      status: "error",
      error: "Invalid input. Please check the fields.",
      fieldErrors: validatedFields.error.flatten().fieldErrors,
    };
  }
  
  const preferences: OriginalPreferences = validatedFields.data;

  try {
    // Pass all preferences, including foodPreference, to the Genkit flow
    const result = await generateTravelPlanOptions(preferences as GenerateTravelPlanOptionsInput);
    return { 
      status: "success", 
      options: result.options, 
      originalPreferences: preferences, 
      error: null 
    };
  } catch (error) {
    console.error("Error generating travel plan options:", error);
    return { 
      status: "error", 
      error: "Failed to generate travel options. The AI service might be busy. Please try again.",
      originalPreferences: preferences, 
    };
  }
}


export async function elaborateSelectedPlanAction(
  prevState: ElaborationFormState,
  formData: FormData
): Promise<ElaborationFormState> {
  const selectedPlanId = formData.get('selectedPlanId') as string;
  const selectedPlanTitle = formData.get('selectedPlanTitle') as string;
  const selectedPlanBriefDescription = formData.get('selectedPlanBriefDescription') as string;
  
  const originalPreferencesData = {
    duration: formData.get('originalDuration') as string,
    interests: formData.get('originalInterests') as string,
    foodPreference: formData.get('originalFoodPreference') as string | undefined, // Added foodPreference
    budget: formData.get('originalBudget') as string,
    country: formData.get('originalCountry') as string | undefined,
    city: formData.get('originalCity') as string | undefined,
  };

  const validatedPrefs = PreferenceSchema.safeParse(originalPreferencesData);
  if (!validatedPrefs.success) {
     return {
      status: "error",
      error: "Internal error: Original preferences are invalid.",
      fieldErrors: validatedPrefs.error.flatten().fieldErrors,
    };
  }

  if (!selectedPlanId || !selectedPlanTitle || !selectedPlanBriefDescription) {
    return {
      status: "error",
      error: "Internal error: Selected plan details are missing.",
    };
  }

  const elaborationInput: ElaborateSelectedPlanInput = {
    selectedPlanTitle,
    selectedPlanBriefDescription,
    originalPreferences: validatedPrefs.data, // This now includes foodPreference
  };

  try {
    const result = await elaborateSelectedPlan(elaborationInput);
    if (!result || !result.dailyPlans || result.dailyPlans.length === 0) {
      console.error("Elaboration result is missing daily plans:", result);
      return {
        status: "error",
        error: "The AI generated an incomplete itinerary. Please try again or choose another option.",
      };
    }
    return { 
      status: "success", 
      detailedItinerary: result, 
      error: null 
    };
  } catch (error) {
    console.error("Error elaborating selected plan:", error);
    const errorMessage = error instanceof Error ? error.message : "An unknown error occurred.";
    return { 
      status: "error", 
      error: `Failed to elaborate the selected plan: ${errorMessage}. The AI service might be busy or the response was not as expected. Please try again.` 
    };
  }
}
