
// src/app/planner/page.tsx
"use client";

import { useState, useEffect, useActionState } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/contexts/AuthContext';
import { AppHeader } from '@/components/wander-genie/AppHeader';
import { PreferenceForm } from '@/components/wander-genie/PreferenceForm';
import { ItineraryDisplay } from '@/components/wander-genie/ItineraryDisplay';
import { TravelPlanOptionsDisplay } from '@/components/wander-genie/TravelPlanOptionsDisplay';
import { 
  generateOptionsAction, 
  elaborateSelectedPlanAction,
  type OptionsFormState,
  type ElaborationFormState,
} from '@/app/actions'; // Adjusted path if actions.ts moved or for clarity
import { useToast } from "@/hooks/use-toast";
import Image from 'next/image';
import { Button } from '@/components/ui/button';
import { Compass, ListChecks, Route, Loader2, Wand2, AlertTriangle, MapPin } from 'lucide-react';
import { APIProvider, Map, Marker } from '@vis.gl/react-google-maps';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';


export default function PlannerPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();

  const initialOptionsState: OptionsFormState = { status: 'initial' };
  const initialElaborationState: ElaborationFormState = { status: 'initial' };

  const [optionsState, optionsFormAction, optionsPending] = useActionState(generateOptionsAction, initialOptionsState);
  const [elaborationState, elaborationFormAction, elaborationPending] = useActionState(elaborateSelectedPlanAction, initialElaborationState);
  
  const [selectedPlanIdToElaborate, setSelectedPlanIdToElaborate] = useState<string | null>(null);
  const [currentView, setCurrentView] = useState<'form_initial' | 'options_loading' | 'options_display' | 'elaboration_loading' | 'itinerary_display'>('form_initial');

  const { toast } = useToast();
  const [googleMapsApiKey, setGoogleMapsApiKey] = useState<string | null>(null);

  useEffect(() => {
    if (!authLoading && !user) {
      router.push('/login?redirect=/planner');
    }
  }, [user, authLoading, router]);

  useEffect(() => {
    const key = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;
    setGoogleMapsApiKey(key || ""); 
  }, []);


  useEffect(() => {
    if (optionsPending) {
      setCurrentView('options_loading');
    } else if (optionsState.status === 'success' && optionsState.options) {
      setCurrentView('options_display');
    } else if (optionsState.status === 'error') {
      toast({
        title: "Oops! Options Error.",
        description: optionsState.error || "Failed to generate travel options.",
        variant: "destructive",
      });
      setCurrentView('form_initial');
    } else if (optionsState.status === 'initial') {
      setCurrentView('form_initial');
    }
  }, [optionsState, optionsPending, toast]);

  useEffect(() => {
    if (elaborationPending) {
      setCurrentView('elaboration_loading');
    } else if (elaborationState.status === 'success' && elaborationState.detailedItinerary) {
      toast({
        title: "Adventure Crafted!",
        description: "Your detailed itinerary is ready.",
        variant: "default",
        className: "bg-primary text-primary-foreground border-primary/50"
      });
      setCurrentView('itinerary_display');
      setSelectedPlanIdToElaborate(null); 
    } else if (elaborationState.status === 'error') {
      toast({
        title: "Oops! Elaboration Error.",
        description: elaborationState.error || "Failed to elaborate the plan.",
        variant: "destructive",
      });
      setCurrentView(optionsState.status === 'success' ? 'options_display' : 'form_initial');
      setSelectedPlanIdToElaborate(null); 
    }
  }, [elaborationState, elaborationPending, toast, optionsState.status]);


  const handleBackToOptions = () => {
    setCurrentView('options_display'); 
    setSelectedPlanIdToElaborate(null);
  };

  const handleStartNewSearch = () => {
    window.location.reload(); 
  };

  if (authLoading || !user) {
    return (
      <div className="flex flex-col min-h-screen bg-gradient-to-br from-background to-muted/50 text-foreground">
        <AppHeader />
        <main className="container mx-auto px-4 py-8 md:px-6 md:py-12 flex-grow flex items-center justify-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary" />
           <p className="ml-4 text-lg">Loading planner...</p>
        </main>
         <footer className="text-center py-6 px-4 text-sm text-muted-foreground border-t border-border/50 bg-background/80">
            WanderGenie &copy; {new Date().getFullYear()}
        </footer>
      </div>
    );
  }


  const renderOutputSection = () => {
    switch (currentView) {
      case 'form_initial':
        if (optionsState.status === 'initial' || (optionsState.status === 'error' && !optionsPending) ) {
             if(optionsState.status === 'error' && optionsState.error && !optionsState.fieldErrors) {
                return (
                    <div className="text-center p-8 bg-card rounded-lg shadow-md border border-destructive/50">
                        <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
                        <h3 className="text-xl font-semibold text-destructive">Error Generating Options</h3>
                        <p className="text-muted-foreground mt-1">{optionsState.error}</p>
                        <p className="text-muted-foreground mt-2">Please review your preferences in the form above and try submitting again.</p>
                    </div>
                );
             }
          return (
            <div className="flex flex-col items-center justify-center min-h-[300px] bg-card p-10 rounded-lg shadow-lg border-2 border-primary/20 text-center">
              <div className="w-full max-h-60 mb-8 overflow-hidden rounded-lg shadow-md">
                <Image 
                    src="https://picsum.photos/1200/400?random=2" 
                    alt="Scenic landscape inviting exploration" 
                    width={1200} 
                    height={400} 
                    className="object-cover w-full h-full"
                    data-ai-hint="adventure landscape"
                    priority 
                />
              </div>
              <h2 className="text-3xl font-bold text-primary mb-3">Ready to Explore the Unseen?</h2>
              <p className="text-lg text-foreground/80 mb-6 max-w-2xl">
                  Your next unforgettable journey to hidden gems and underrated wonders is just a few clicks away. 
                  Fill in your travel preferences, and let WanderGenie unveil a world of possibilities!
              </p>
              <ListChecks className="h-12 w-12 text-accent animate-bounce" />
            </div>
          );
        }
        return null;

      case 'options_loading':
        return (
          <div className="flex flex-col justify-center items-center min-h-[300px] bg-card p-8 rounded-lg shadow-lg border-2 border-primary/20">
            <div className="flex flex-col items-center text-center">
              <Loader2 className="animate-spin h-16 w-16 text-primary mb-6" />
              <h2 className="text-2xl font-semibold text-primary mb-2">Searching for Adventure Options...</h2>
              <p className="text-muted-foreground max-w-md">
                WanderGenie is brainstorming unique travel ideas for you. This might take a moment.
              </p>
            </div>
          </div>
        );

      case 'options_display':
        if (optionsState.status === 'success' && optionsState.options && optionsState.originalPreferences) {
          return (
            <TravelPlanOptionsDisplay 
              options={optionsState.options} 
              originalPreferences={optionsState.originalPreferences}
              elaborationFormAction={elaborationFormAction}
              elaborationState={elaborationState}
              isElaboratingAny={elaborationPending || currentView === 'elaboration_loading'}
              setSelectedPlanIdToElaborate={setSelectedPlanIdToElaborate}
              selectedPlanIdBeingElaborated={selectedPlanIdToElaborate}
            />
          );
        }
        return <p className="text-center text-muted-foreground">Loading options or an unexpected error occurred.</p>;

      case 'elaboration_loading':
        return (
          <div className="flex flex-col justify-center items-center min-h-[300px] bg-card p-8 rounded-lg shadow-lg border-2 border-primary/20">
            <div className="flex flex-col items-center text-center">
              <Loader2 className="animate-spin h-16 w-16 text-primary mb-6" />
              <h2 className="text-2xl font-semibold text-primary mb-2">Crafting Your Detailed Itinerary...</h2>
              <p className="text-muted-foreground max-w-md">
                Adding the final touches to your chosen adventure plan. Please wait a few seconds.
              </p>
            </div>
          </div>
        );

      case 'itinerary_display':
        if (elaborationState.status === 'success' && elaborationState.detailedItinerary) {
          const defaultCenter = { lat: 22.5726, lng: 88.3639 }; 
          
          let mapContent;
          if (googleMapsApiKey === null) { 
             mapContent = (
                 <Card className="mt-8 shadow-lg border-2 border-muted">
                  <CardHeader>
                    <CardTitle className="text-xl font-semibold text-primary flex items-center">
                       <Loader2 className="animate-spin mr-2 h-5 w-5" /> Loading Map...
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      The interactive map will be displayed shortly once the API key is loaded.
                    </p>
                  </CardContent>
                </Card>
            );
          } else if (!googleMapsApiKey) { 
            mapContent = (
                <Card className="mt-8 shadow-lg border-2 border-destructive/50">
                  <CardHeader>
                    <CardTitle className="text-xl font-semibold text-destructive flex items-center">
                      <AlertTriangle className="mr-2 h-5 w-5" /> Map Configuration Error
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-foreground">
                      The Google Maps API key is not configured. Please set the <code className="bg-muted px-1 py-0.5 rounded text-sm font-mono">NEXT_PUBLIC_GOOGLE_MAPS_API_KEY</code> environment variable.
                    </p>
                    <p className="text-sm text-muted-foreground mt-2">
                      Map functionality is currently unavailable.
                    </p>
                  </CardContent>
                </Card>
            );
          } else { 
            mapContent = (
              <Card className="mt-8 shadow-xl border-2 border-primary/20">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-primary flex items-center">
                    <MapPin className="mr-3 h-7 w-7" />
                    Interactive Map
                  </CardTitle>
                  <CardDescription className="text-foreground/80">
                    Explore locations related to your itinerary. (Current map shows a default location)
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <APIProvider apiKey={googleMapsApiKey}>
                    <div style={{ height: '450px', width: '100%', borderRadius: 'var(--radius)' }} className="overflow-hidden shadow-md border border-border">
                      <Map 
                        defaultCenter={defaultCenter} 
                        defaultZoom={9} 
                        mapId="wandergenie-map-1"
                        gestureHandling="greedy"
                        disableDefaultUI={true}
                      >
                        <Marker position={defaultCenter} title="Default Location" />
                      </Map>
                    </div>
                  </APIProvider>
                </CardContent>
              </Card>
            );
          }

          return (
            <>
              <ItineraryDisplay itineraryOutput={elaborationState.detailedItinerary} />
              {mapContent}
              <div className="flex flex-col sm:flex-row justify-center gap-4 mt-8">
                <Button onClick={handleBackToOptions} variant="outline" size="lg" className="w-full sm:w-auto">
                  <ListChecks className="mr-2 h-5 w-5" /> Back to Options
                </Button>
                <Button onClick={handleStartNewSearch} variant="secondary" size="lg" className="w-full sm:w-auto">
                  <Wand2 className="mr-2 h-5 w-5" /> Start New Search
                </Button>
              </div>
            </>
          );
        }
        if (elaborationState.status === 'error') {
            return (
                <div className="text-center p-8 bg-card rounded-lg shadow-md border border-destructive/50">
                    <AlertTriangle className="mx-auto h-12 w-12 text-destructive mb-4" />
                    <h3 className="text-xl font-semibold text-destructive">Could Not Create Itinerary</h3>
                    <p className="text-muted-foreground mt-1">{elaborationState.error || "An unexpected error occurred."}</p>
                    <div className="flex flex-col sm:flex-row justify-center gap-4 mt-6">
                        <Button onClick={handleBackToOptions} variant="outline" size="lg" className="w-full sm:w-auto">
                            <ListChecks className="mr-2 h-5 w-5" /> Back to Options
                        </Button>
                        <Button onClick={handleStartNewSearch} variant="secondary" size="lg" className="w-full sm:w-auto">
                           <Wand2 className="mr-2 h-5 w-5" /> Start New Search
                        </Button>
                    </div>
                </div>
            );
        }
        return <p className="text-center text-muted-foreground">Loading itinerary or an unexpected error occurred.</p>;
      
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gradient-to-br from-background to-muted/50 text-foreground">
      <AppHeader />
      <main className="container mx-auto px-4 py-8 md:px-6 md:py-12 flex-grow">
        <div className="mb-12">
          <PreferenceForm 
            formAction={optionsFormAction} 
            initialState={optionsState}
            isSubmitting={optionsPending}
          />
        </div>
        
        <div className="output-section space-y-8">
          {renderOutputSection()}
        </div>
      </main>
      <footer className="text-center py-6 px-4 text-sm text-muted-foreground border-t border-border/50 bg-background/80">
        WanderGenie &copy; {new Date().getFullYear()} - Your AI Companion for Offbeat Adventures.
      </footer>
    </div>
  );
}

