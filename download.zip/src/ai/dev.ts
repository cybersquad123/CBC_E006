import { config } from 'dotenv';
config();

import '@/ai/flows/summarize-destination-info.ts';
import '@/ai/flows/generate-itinerary.ts';
import '@/ai/flows/generate-travel-plan-options.ts';
import '@/ai/flows/elaborate-selected-plan.ts';
import '@/ai/tools/search-web-for-rating.ts'; // Added import for the new tool
