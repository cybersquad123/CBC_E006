'use server';

/**
 * @fileOverview Summarizes key details about a travel destination, including points of interest and travel tips.
 *
 * - summarizeDestinationInfo - A function that summarizes destination information.
 * - SummarizeDestinationInfoInput - The input type for the summarizeDestinationInfo function.
 * - SummarizeDestinationInfoOutput - The return type for the summarizeDestinationInfo function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SummarizeDestinationInfoInputSchema = z.object({
  destinationName: z.string().describe('The name of the destination.'),
  description: z.string().describe('A detailed description of the destination.'),
  pointsOfInterest: z.string().describe('Key points of interest at the destination.'),
  travelTips: z.string().describe('Important travel tips for the destination.'),
});
export type SummarizeDestinationInfoInput = z.infer<
  typeof SummarizeDestinationInfoInputSchema
>;

const SummarizeDestinationInfoOutputSchema = z.object({
  summary: z.string().describe('A concise summary of the destination, including key details and travel tips.'),
});
export type SummarizeDestinationInfoOutput = z.infer<
  typeof SummarizeDestinationInfoOutputSchema
>;

export async function summarizeDestinationInfo(
  input: SummarizeDestinationInfoInput
): Promise<SummarizeDestinationInfoOutput> {
  return summarizeDestinationInfoFlow(input);
}

const summarizeDestinationInfoPrompt = ai.definePrompt({
  name: 'summarizeDestinationInfoPrompt',
  input: {schema: SummarizeDestinationInfoInputSchema},
  output: {schema: SummarizeDestinationInfoOutputSchema},
  prompt: `Summarize the following destination information, including key points of interest and travel tips, into a concise and engaging summary:

Destination: {{destinationName}}
Description: {{description}}
Points of Interest: {{pointsOfInterest}}
Travel Tips: {{travelTips}}`,
});

const summarizeDestinationInfoFlow = ai.defineFlow(
  {
    name: 'summarizeDestinationInfoFlow',
    inputSchema: SummarizeDestinationInfoInputSchema,
    outputSchema: SummarizeDestinationInfoOutputSchema,
  },
  async input => {
    const {output} = await summarizeDestinationInfoPrompt(input);
    return output!;
  }
);
