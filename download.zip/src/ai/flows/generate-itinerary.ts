// This is an AI-powered travel itinerary generator for offbeat and underrated destinations.
// It takes user preferences such as duration, interests, budget, and optional location context (country/city)
// and provides a personalized itinerary suggestion.
// - generateItinerary - A function that generates a travel itinerary based on user preferences.
// - GenerateItineraryInput - The input type for the generateItinerary function.
// - GenerateItineraryOutput - The return type for the generateItinerary function.

// NOTE: This flow is being superseded by generate-travel-plan-options.ts and elaborate-selected-plan.ts
// for a multi-step generation process. Its types (GenerateItineraryInput, GenerateItineraryOutput)
// are currently reused by the new flows.

'use server';

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const GenerateItineraryInputSchema = z.object({
  duration: z.string().describe('The duration of the trip in days.'),
  interests: z.string().describe('The interests of the traveler (e.g., hiking, food, history).'),
  foodPreference: z.string().optional().describe('The food preferences of the traveler (e.g., vegetarian, seafood lover).'),
  budget: z.string().describe('The budget of the traveler (e.g., low, medium, high).'),
  country: z.string().optional().describe('The preferred country for the trip (optional).'),
  city: z.string().optional().describe('The preferred city or starting point for the trip (optional).'),
});

export type GenerateItineraryInput = z.infer<typeof GenerateItineraryInputSchema>;

const GenerateItineraryOutputSchema = z.object({
  itinerary: z.string().describe('A personalized itinerary suggestion for offbeat and underrated destinations, formatted as paragraphs separated by newlines.'),
});

export type GenerateItineraryOutput = z.infer<typeof GenerateItineraryOutputSchema>;

// This function is unlikely to be called directly anymore.
export async function generateItinerary(input: GenerateItineraryInput): Promise<GenerateItineraryOutput> {
  return generateItineraryFlow(input);
}

const generateItineraryPrompt = ai.definePrompt({
  name: 'generateItineraryPrompt',
  input: {schema: GenerateItineraryInputSchema},
  output: {schema: GenerateItineraryOutputSchema},
  prompt: `You are a travel expert specializing in offbeat and underrated destinations.

Based on the user's preferences, generate a personalized itinerary suggestion.
Format the itinerary as a series of paragraphs. Each paragraph should be separated by a newline character.

{{#if country}}
The user has expressed an interest in starting or focusing their trip in or around {{country}}.
{{#if city}}
Specifically, they mentioned {{city}} as a potential starting point or area of interest.
Use this information to find nearby offbeat and underrated destinations and activities.
{{else}}
Use this information to find offbeat and underrated destinations and activities within or near {{country}}.
{{/if}}
{{else}}
The user has not specified a country or city, so feel free to suggest destinations globally that match their other preferences.
{{/if}}

Please provide a detailed itinerary based on the following:
- Duration: {{{duration}}} days
- Interests: {{{interests}}}
{{#if foodPreference}}- Food Preferences: {{{foodPreference}}}{{/if}}
- Budget: {{{budget}}}
{{#if country}}- Preferred Country: {{{country}}}{{/if}}
{{#if city}}- Preferred City/Region: {{{city}}}{{/if}}

Begin the itinerary below:
Itinerary:`,
});

const generateItineraryFlow = ai.defineFlow(
  {
    name: 'generateItineraryFlow',
    inputSchema: GenerateItineraryInputSchema,
    outputSchema: GenerateItineraryOutputSchema,
  },
  async input => {
    const {output} = await generateItineraryPrompt(input);
    return output!;
  }
);
