'use server';
/**
 * @fileOverview Elaborates on a user-selected travel plan option to generate a detailed, structured itinerary.
 *
 * - elaborateSelectedPlan - A function that handles the detailed itinerary generation for a selected plan.
 * - ElaborateSelectedPlanInput - The input type for the function.
 * - ElaborateSelectedPlanOutput - The return type for the function (structured detailed itinerary).
 * - DayPlan - The type for a single day's plan within the itinerary.
 */

import {ai} from '@/ai/genkit';
import {z}from 'genkit';

// Input schema: details of the selected plan and original user preferences
const ElaborateSelectedPlanInputSchema = z.object({
  selectedPlanTitle: z.string().describe('The title of the travel plan previously selected by the user.'),
  selectedPlanBriefDescription: z.string().describe('The brief description of the travel plan selected by the user.'),
  originalPreferences: z.object({ 
    duration: z.string().describe('The original duration of the trip in days.'),
    interests: z.string().describe('The original interests of the traveler.'),
    foodPreference: z.string().optional().describe('The original food preferences of the traveler.'),
    budget: z.string().describe('The original budget of the traveler.'),
    country: z.string().optional().describe('The original preferred country (optional).'),
    city: z.string().optional().describe('The original preferred city/starting point (optional).'),
  }).describe("The user's original travel preferences."),
});
export type ElaborateSelectedPlanInput = z.infer<typeof ElaborateSelectedPlanInputSchema>;

// Schema for a single day's plan
const DayPlanSchema = z.object({
  day: z.string().describe('The day number or a descriptive title for the day (e.g., "Day 1", "Arrival & Exploration").'),
  itinerary: z.string().describe('A detailed description of activities, sights, and experiences for this day. Should be formatted with newlines for readability if needed.'),
  budget: z.string().optional().describe('Estimated budget or specific budget notes for this day (e.g., "Approx. $50 for meals & museum entry").'),
});
export type DayPlan = z.infer<typeof DayPlanSchema>;

// Output schema for the structured, detailed itinerary
const ElaborateSelectedPlanOutputSchema = z.object({
  planTitle: z.string().describe('The overall title for the elaborated travel plan, can be same or similar to selectedPlanTitle.'),
  dailyPlans: z.array(DayPlanSchema).describe('An array of day-by-day plans, each containing a day description, detailed itinerary, and optional budget notes for that day.'),
  overallBudgetSummary: z.string().optional().describe('A brief summary of the overall budget considerations for the trip, complementing the daily notes.'),
});
export type ElaborateSelectedPlanOutput = z.infer<typeof ElaborateSelectedPlanOutputSchema>;


export async function elaborateSelectedPlan(input: ElaborateSelectedPlanInput): Promise<ElaborateSelectedPlanOutput> {
  return elaborateSelectedPlanFlow(input);
}

const elaborateSelectedPlanPrompt = ai.definePrompt({
  name: 'elaborateSelectedPlanPrompt',
  input: {schema: ElaborateSelectedPlanInputSchema},
  output: {schema: ElaborateSelectedPlanOutputSchema},
  prompt: `You are a travel expert specializing in detailed itinerary planning for offbeat and underrated destinations.
The user has selected the following travel plan idea:
- Plan Title: "{{selectedPlanTitle}}"
- Brief Description: "{{selectedPlanBriefDescription}}"

Your task is to expand this selected plan into a comprehensive, structured itinerary.
You MUST provide the output as a single JSON object strictly adhering to the specified output schema.

Incorporate the user's original preferences:
- Duration: {{originalPreferences.duration}}
- Interests: {{originalPreferences.interests}}
{{#if originalPreferences.foodPreference}}- Food Preferences: {{originalPreferences.foodPreference}}{{/if}}
- Budget: {{originalPreferences.budget}}
{{#if originalPreferences.country}}
- Original Preferred Country Context: {{originalPreferences.country}}
  {{#if originalPreferences.city}}
  - Original Preferred City/Region Context: {{originalPreferences.city}}
  {{/if}}
(Use this context to ensure the detailed plan aligns with any initial location thoughts, while still focusing on the selected plan's theme.)
{{else}}
(The selected plan might have its own implicit location; focus on that.)
{{/if}}

The output JSON object must have the following top-level fields:
1.  'planTitle': A string for the overall title of this elaborated travel plan. This can be the same as or similar to the input "selectedPlanTitle".
2.  'dailyPlans': An array of objects. Each object in this array represents one day of the trip (or a logical segment if not strictly day-by-day) and MUST contain these fields:
    a.  'day': A string indicating the day number or a descriptive name (e.g., "Day 1", "Arrival Day & City Exploration", "Thematic Exploration: Ancient Ruins").
    b.  'itinerary': A string containing a detailed description of activities, sights, and experiences for that day. This should be engaging, practical, and well-described. Use newline characters (\\n) within this string if needed for better formatting of the day's plan. Also consider the user's food preferences ({{originalPreferences.foodPreference}}) when suggesting dining options or food-related activities.
    c.  'budget': An optional string providing a budget estimate or specific notes for that particular day (e.g., "Approx. $50 for food and entrance fees", "Budget-friendly street food focus", "Museum tickets: $20, Dinner: $40"). If no specific daily budget notes are relevant or calculable, you can omit this field or provide a general comment like "Covered by overall budget".
3.  'overallBudgetSummary': An optional string providing a general overview of the trip's budget considerations, reflecting the user's preference (e.g., "This plan leans towards a {{originalPreferences.budget}} budget, with most activities being free or low-cost, and dining options ranging from local eateries to mid-range restaurants.").

Example of a 'dailyPlans' array item:
{
  "day": "Day 1: Arrival and Coastal Charm",
  "itinerary": "Arrive at Coastal Town airport. Transfer to your pre-booked guesthouse. \nAfter settling in, take an afternoon stroll to explore the historic lighthouse and enjoy a scenic walk along the rugged cliffs, offering breathtaking views. \nFor the evening, a welcome dinner at 'The Salty Seagull', a highly-rated local seafood restaurant known for fresh catches (vegetarian options available if {{originalPreferences.foodPreference}} includes it).",
  "budget": "Dinner approx. $40-$60. Lighthouse entry: $5. Local transport: $10."
}

Ensure the entire output is a single, valid JSON object that conforms to the output schema. Be creative and ensure the itinerary truly brings the selected plan to life, making it practical and exciting.
The number of daily plans should generally align with the specified trip 'duration'.
`,
});


const elaborateSelectedPlanFlow = ai.defineFlow(
  {
    name: 'elaborateSelectedPlanFlow',
    inputSchema: ElaborateSelectedPlanInputSchema,
    outputSchema: ElaborateSelectedPlanOutputSchema,
  },
  async (input) => {
    const {output} = await elaborateSelectedPlanPrompt(input);
    if (!output) {
      throw new Error("The AI model did not return a valid output for the detailed itinerary.");
    }
    if (!output.planTitle || !Array.isArray(output.dailyPlans) || output.dailyPlans.length === 0) {
        console.warn("AI output might be missing key fields for detailed itinerary:", output);
    }
    return output;
  }
);
