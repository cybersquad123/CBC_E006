'use server';
/**
 * @fileOverview Generates multiple distinct travel plan options based on user preferences, including ratings.
 *
 * - generateTravelPlanOptions - A function that handles the travel plan option generation.
 * - GenerateTravelPlanOptionsInput - The input type for the function.
 * - GenerateTravelPlanOptionsOutput - The return type for the function.
 * - TravelPlanOption - The type for a single travel plan option, now including rating info.
 */

import {ai} from '@/ai/genkit';
import {z}from 'genkit';
// Removed direct import of GenerateItineraryInput as we define a more specific one here.
import { searchWebForDestinationRating } from '@/ai/tools/search-web-for-rating';

// Schema for a single travel plan option, now with rating fields
const TravelPlanOptionSchema = z.object({
  id: z.string().describe("A unique identifier for the travel plan option, e.g., 'option_1', 'option_alpha'."),
  title: z.string().max(100).describe('A short, catchy title for the travel plan (max 15 words).'),
  briefDescription: z.string().max(500).describe('A concise summary of the travel plan (2-4 sentences), highlighting its unique appeal.'),
  rating: z.number().min(1).max(5).optional().describe('A numerical rating for the travel plan (1-5), obtained using the searchWebForDestinationRating tool.'),
  ratingSource: z.string().url().optional().describe('The source URL for the rating, if available from the tool.'),
  reviewCount: z.number().int().positive().optional().describe('Number of reviews the rating is based on, if available from the tool.'),
});
export type TravelPlanOption = z.infer<typeof TravelPlanOptionSchema>;

// Input schema specifically for generating travel plan options
const GenerateTravelPlanOptionsInputSchema = z.object({
  duration: z.string().describe('The duration of the trip in days.'),
  interests: z.string().describe('The interests of the traveler (e.g., hiking, food, history).'),
  foodPreference: z.string().optional().describe('The food preferences of the traveler (e.g., vegetarian, seafood lover, local street food).'),
  budget: z.string().describe('The budget of the traveler (e.g., low, medium, high).'),
  country: z.string().optional().describe('The preferred country for the trip (optional).'),
  city: z.string().optional().describe('The preferred city or starting point for the trip (optional).'),
});
export type GenerateTravelPlanOptionsInput = z.infer<typeof GenerateTravelPlanOptionsInputSchema>;


// Output schema for the travel plan options
const GenerateTravelPlanOptionsOutputSchema = z.object({
  options: z.array(TravelPlanOptionSchema)
    .min(1, "At least one travel plan option must be provided.")
    .describe('An array of distinct travel plan options, sorted by rating in descending order.'),
});
export type GenerateTravelPlanOptionsOutput = z.infer<typeof GenerateTravelPlanOptionsOutputSchema>;


export async function generateTravelPlanOptions(input: GenerateTravelPlanOptionsInput): Promise<GenerateTravelPlanOptionsOutput> {
  return generateTravelPlanOptionsFlow(input);
}

const generateTravelPlanOptionsPrompt = ai.definePrompt({
  name: 'generateTravelPlanOptionsPrompt',
  input: {schema: GenerateTravelPlanOptionsInputSchema},
  output: {schema: GenerateTravelPlanOptionsOutputSchema},
  tools: [searchWebForDestinationRating], 
  prompt: `You are a travel expert specializing in creating unique and offbeat travel experiences.
Based on the user's preferences, generate a diverse list of distinct travel plan options.
Each option should focus on underrated destinations or unique approaches to popular areas, fitting the user's interests, food preferences, and budget.

For EACH travel plan option you generate:
1.  Create a unique 'id' (e.g., 'option_1', 'option_alpha').
2.  Craft a short, catchy 'title' (max 15 words).
3.  Write a 'briefDescription' (2-4 sentences) summarizing the plan and its appeal.
4.  IMPORTANT: Use the 'searchWebForDestinationRating' tool to get a rating for the plan. The searchTerm for the tool should be the 'title' of the plan you just_generated.
5.  Include the 'rating', 'ratingSource', and 'reviewCount' fields in the option object based on the tool's output. If the tool doesn't provide a rating, you may omit these fields or use a default/placeholder if appropriate, but prioritize using the tool.

User Preferences:
- Duration: {{{duration}}}
- Interests: {{{interests}}}
{{#if foodPreference}}- Food Preferences: {{{foodPreference}}}{{/if}}
- Budget: {{{budget}}}
{{#if country}}
- Preferred Country Context: {{{country}}}
  {{#if city}}
  - Preferred City/Region Context: {{{city}}} (Use this to find nearby or related offbeat options)
  {{else}}
  (Consider offbeat options within or near this country)
  {{/if}}
{{else}}
(No specific location preference, suggest globally based on other criteria)
{{/if}}

After generating all options and fetching their ratings, sort the entire list of options in DESCENDING order based on the 'rating' field (highest rated first).
Provide all generated and sorted options in the specified output format. Emphasize variety among the options.
`,
});

const generateTravelPlanOptionsFlow = ai.defineFlow(
  {
    name: 'generateTravelPlanOptionsFlow',
    inputSchema: GenerateTravelPlanOptionsInputSchema,
    outputSchema: GenerateTravelPlanOptionsOutputSchema,
  },
  async (input) => {
    const {output} = await generateTravelPlanOptionsPrompt(input);
    
    if (output && output.options) {
      output.options.sort((a, b) => {
        const ratingA = a.rating ?? -1; 
        const ratingB = b.rating ?? -1;
        
        if (ratingB !== ratingA) {
          return ratingB - ratingA;
        }
        const reviewCountA = a.reviewCount ?? 0;
        const reviewCountB = b.reviewCount ?? 0;
        return reviewCountB - reviewCountA;
      });
    }
    
    return output!;
  }
);
