// src/components/wander-genie/WanderGenieLogo.tsx
import type { SVGProps } from 'react';

export function WanderGenieLogo(props: SVGProps<SVGSVGElement>) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 480 100"
      aria-label="WanderGenie Logo"
      {...props}
    >
      <style>
        {`
          .wander-text {
            font-family: 'Georgia', serif;
            font-size: 50px;
            font-weight: bold;
            fill: currentColor;
            dominant-baseline: middle;
            text-anchor: start;
          }
          .genie-text {
            font-family: 'Georgia', serif;
            font-size: 50px;
            font-weight: bold;
            fill: currentColor;
            dominant-baseline: middle;
            text-anchor: start;
          }
          .lamp-group {
            fill: #3B82F6; /* Tailwind blue-500, a nice contrasting blue */
            /* fill: hsl(var(--accent)); Could also use accent color from theme */
          }
        `}
      </style>
      <text x="10" y="50" className="wander-text">
        Wander
      </text>

      {/* Genie Lamp SVG */}
      <g className="lamp-group" transform="translate(240, 50) scale(0.6)">
        {/* Lamp Body */}
        <path d="M60.62,29.73c-11.28,0-20.44,9.16-20.44,20.44S49.34,70.61,60.62,70.61s20.44-9.16,20.44-20.44S71.9,29.73,60.62,29.73z" />
        {/* Lamp Spout */}
        <path d="M77.93,45.77c-0.58-1.44-1.39-2.78-2.39-4c-2.37-2.85-5.08-4.93-7.86-6.11c-0.88-0.38-1.74-0.58-2.51-0.69 c-0.02,0-0.04-0.01-0.06-0.01 c-1.07-0.14-2.08-0.21-3.02-0.21h-0.02c-1.83,0-3.43,0.24-4.98,0.79c-1.08,0.39-2.22,0.97-3.39,1.75 c-1.19,0.79-2.32,1.74-3.36,2.83c-1.03,1.08-1.92,2.3-2.61,3.61c-1.95,3.68-2.42,7.89-1.3,12.01c0.33,1.23,0.79,2.43,1.37,3.56 c0.73,1.41,1.62,2.73,2.66,3.95l0,0c0.02,0.02,0.03,0.04,0.05,0.06c0.63,0.74,1.3,1.43,2.03,2.06 c3.66,3.14,8.33,4.82,13.19,4.82c1.61,0,3.22-0.2,4.82-0.61c0.97-0.25,1.93-0.57,2.88-0.96L77.93,45.77z M50.17,66.86 c-0.9-1.12-1.67-2.32-2.28-3.6c-0.52-1.09-0.91-2.22-1.18-3.38c-0.88-3.74-0.48-7.44,0.93-10.73c0.61-1.41,1.47-2.73,2.54-3.94 c0.96-1.08,1.98-1.98,3.04-2.68c1.05-0.7,2.05-1.22,2.99-1.55c1.32-0.46,2.68-0.68,4.13-0.68h0.02c0.81,0,1.69,0.06,2.62,0.18 c0.02,0,0.03,0.01,0.05,0.01c0.68,0.08,1.44,0.26,2.24,0.59c2.48,1.03,4.91,2.88,7.07,5.46c0.91,1.09,1.64,2.28,2.17,3.55 l-22.03,16.7V66.86z" />
        {/* Lamp Handle */}
        <path d="M32.08,50.17C32.08,38,40.87,28.3,51.19,27.08c-1.76-2.04-3.94-3.7-6.39-4.85c-2.83-1.33-5.94-2.02-9.14-2.02 C22.27,20.21,11,32.05,11,46.78c0,4.08,1.06,8.04,3.05,11.55C16.61,63.76,20.42,67,25,68.89c1.11,0.46,2.27,0.82,3.48,1.07 C30.13,70.54,32.08,61.63,32.08,50.17z" />
        {/* Lamp Lid */}
        <path d="M60.62,18.58c-3.74,0-6.78,3.04-6.78,6.78s3.04,6.78,6.78,6.78s6.78-3.04,6.78-6.78S64.36,18.58,60.62,18.58z" />
        {/* Lamp Base */}
        <ellipse cx="60.62" cy="75.52" rx="14.93" ry="5.56" />
      </g>

      <text x="300" y="50" className="genie-text">
        Genie
      </text>
    </svg>
  );
}
