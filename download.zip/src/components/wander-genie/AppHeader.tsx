// src/components/wander-genie/AppHeader.tsx
"use client";

import { LogIn, LogOut } from 'lucide-react'; // Removed Globe, UserCircle (already commented)
import { useAuth } from '@/contexts/AuthContext';
import { auth } from '@/lib/firebase/config';
import { signOut } from 'firebase/auth';
import { Button } from '@/components/ui/button';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { WanderGenieLogo } from './WanderGenieLogo'; // Import the new logo

export function AppHeader() {
  const { user, loading } = useAuth();
  const router = useRouter();

  const handleLogout = async () => {
    try {
      await signOut(auth);
      router.push('/login'); // Redirect to login page after logout
    } catch (error) {
      console.error("Error signing out: ", error);
      // Optionally, show a toast message for logout error
    }
  };

  return (
    <header className="bg-primary text-primary-foreground py-3 px-4 md:px-6 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto flex items-center justify-between">
        <Link href="/" className="flex items-center hover:opacity-90 transition-opacity">
          {/* Replace Globe icon and h1 text with WanderGenieLogo component */}
          <WanderGenieLogo className="h-10 md:h-12 text-primary-foreground" />
        </Link>
        <div className="flex items-center gap-3">
          {loading ? (
            <div className="h-8 w-20 bg-primary/50 animate-pulse rounded-md"></div>
          ) : user ? (
            <>
              <span className="text-sm hidden sm:inline">Welcome!</span>
              <Button onClick={handleLogout} variant="ghost" size="sm" className="hover:bg-primary/80">
                <LogOut className="mr-1 h-4 w-4" />
                Logout
              </Button>
            </>
          ) : (
            <Button asChild variant="ghost" size="sm" className="hover:bg-primary/80">
              <Link href="/login">
                <LogIn className="mr-1 h-4 w-4" />
                Login
              </Link>
            </Button>
          )}
        </div>
      </div>
    </header>
  );
}
