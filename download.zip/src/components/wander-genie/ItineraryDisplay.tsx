// src/components/wander-genie/ItineraryDisplay.tsx
import * as React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import type { ElaborateSelectedPlanOutput } from '@/ai/flows/elaborate-selected-plan';
import { Compass, CalendarDays, ListChecks, Wallet, Info } from 'lucide-react';

interface ItineraryDisplayProps {
  itineraryOutput: ElaborateSelectedPlanOutput;
}

export function ItineraryDisplay({ itineraryOutput }: ItineraryDisplayProps) {
  const { planTitle, dailyPlans, overallBudgetSummary } = itineraryOutput;

  return (
    <Card className="shadow-xl border-2 border-primary/20 overflow-hidden bg-card">
      <CardHeader className="bg-primary/10">
        <CardTitle className="text-3xl font-bold text-primary flex items-center">
           <Compass className="mr-3 h-8 w-8"/>
           {planTitle || "Your Personalized Itinerary"}
        </CardTitle>
        <CardDescription className="text-foreground/80 text-base">
          An AI-crafted journey just for you. Explore your day-by-day adventure below.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0 md:p-6">
        {/* Replaced ScrollArea with a div configured for y-scrolling */}
        <div className="max-h-[70vh] min-h-[400px] overflow-y-auto">
          {dailyPlans && dailyPlans.length > 0 ? (
            <Table className="w-full">
              <TableHeader className="sticky top-0 bg-card z-10">
                <TableRow className="hover:bg-muted/30">
                  <TableHead className="w-[150px] md:w-[200px] text-primary font-semibold text-base">
                    <div className="flex items-center">
                      <CalendarDays className="mr-2 h-5 w-5" /> Day
                    </div>
                  </TableHead>
                  <TableHead className="text-primary font-semibold text-base">
                     <div className="flex items-center">
                      <ListChecks className="mr-2 h-5 w-5" /> Itinerary
                    </div>
                  </TableHead>
                  <TableHead className="w-[150px] md:w-[200px] text-right text-primary font-semibold text-base">
                    <div className="flex items-center justify-end">
                      <Wallet className="mr-2 h-5 w-5" /> Budget Notes
                    </div>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {dailyPlans.map((plan, index) => (
                  <TableRow key={index} className="hover:bg-muted/20 align-top">
                    <TableCell className="font-medium text-foreground/90 py-4 px-4 md:px-6 border-b">
                      {plan.day}
                    </TableCell>
                    <TableCell className="py-4 px-4 md:px-6 border-b">
                      <p className="whitespace-pre-line text-foreground/90 leading-relaxed">{plan.itinerary}</p>
                    </TableCell>
                    <TableCell className="text-right text-sm text-muted-foreground py-4 px-4 md:px-6 border-b">
                      {plan.budget || 'N/A'}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="p-6 text-center text-muted-foreground min-h-[300px] flex flex-col justify-center items-center">
              <Info className="mx-auto h-12 w-12 text-primary/50 mb-4" />
              <p className="text-lg font-medium">Itinerary Details Pending</p>
              <p>The generated itinerary is currently empty or could not be fully processed. Please try again or adjust your preferences.</p>
            </div>
          )}
        </div>
      </CardContent>
      {overallBudgetSummary && (
        <CardFooter className="bg-primary/5 p-4 md:p-6 border-t">
          <div className="flex items-start text-sm text-foreground/80">
            <Wallet className="mr-3 h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="font-semibold text-primary mb-1">Overall Budget Summary:</h4>
              <p className="leading-relaxed">{overallBudgetSummary}</p>
            </div>
          </div>
        </CardFooter>
      )}
    </Card>
  );
}
