// src/components/wander-genie/PreferenceForm.tsx
"use client";

import { useFormStatus } from 'react-dom';
import type { OptionsFormState } from '@/app/actions'; 
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Wand2, MapPin, Route, Utensils, Building } from 'lucide-react'; // Added Utensils

interface PreferenceFormProps {
  formAction: (payload: FormData) => void; 
  initialState: OptionsFormState; 
  isSubmitting: boolean; 
}

function SubmitButton({ disabled }: { disabled: boolean}) {
  const { pending } = useFormStatus();
  const isDisabled = disabled || pending;

  return (
    <Button type="submit" disabled={isDisabled} className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
      {isDisabled ? (
        <>
          <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Generating Options...
        </>
      ) : (
        <>
          <Route className="mr-2 h-5 w-5" />
          Find My Adventure Options
        </>
      )}
    </Button>
  );
}

export function PreferenceForm({ formAction, initialState, isSubmitting }: PreferenceFormProps) {
  const fieldErrors = initialState?.status === 'error' ? initialState.fieldErrors : undefined;
  
  return (
    <Card className="shadow-xl border-2 border-primary/20">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold text-primary flex items-center">
          <Wand2 className="mr-2 h-7 w-7" />
          Tell Us Your Travel Dreams
        </CardTitle>
        <CardDescription className="text-foreground/80">
          Describe your ideal trip, and our AI will suggest unique adventure options.
        </CardDescription>
      </CardHeader>
      <form action={formAction}>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="duration" className="font-medium text-foreground/90">Trip Duration</Label>
            <Input 
              id="duration" 
              name="duration" 
              placeholder="e.g., 7 days, 2 weeks" 
              required 
              className="bg-background/70 border-input focus:border-primary"
              defaultValue={initialState?.originalPreferences?.duration || ""}
            />
            {fieldErrors?.duration && <p className="text-sm text-destructive">{fieldErrors.duration.join(', ')}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="interests" className="font-medium text-foreground/90">Interests & Activities</Label>
            <Textarea
              id="interests"
              name="interests"
              placeholder="e.g., hiking, local cuisine, historical sites, photography, offbeat cafes"
              required
              className="min-h-[100px] bg-background/70 border-input focus:border-primary"
              defaultValue={initialState?.originalPreferences?.interests || ""}
            />
            {fieldErrors?.interests && <p className="text-sm text-destructive">{fieldErrors.interests.join(', ')}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="foodPreference" className="font-medium text-foreground/90 flex items-center">
              <Utensils className="mr-1.5 h-4 w-4 text-foreground/70" /> Food Preferences (Optional)
            </Label>
            <Textarea
              id="foodPreference"
              name="foodPreference"
              placeholder="e.g., vegetarian, seafood lover, local street food, gluten-free options"
              className="min-h-[80px] bg-background/70 border-input focus:border-primary"
              defaultValue={initialState?.originalPreferences?.foodPreference || ""}
            />
            {fieldErrors?.foodPreference && <p className="text-sm text-destructive">{fieldErrors.foodPreference.join(', ')}</p>}
          </div>

          <div className="space-y-2">
            <Label htmlFor="budget" className="font-medium text-foreground/90">Budget Preference</Label>
            <Select name="budget" defaultValue={initialState?.originalPreferences?.budget || ""}>
              <SelectTrigger id="budget" className="w-full bg-background/70 border-input focus:border-primary text-foreground">
                <SelectValue placeholder="Select your budget" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Low">Low (Backpacker-friendly)</SelectItem>
                <SelectItem value="Medium">Medium (Comfortable & Value)</SelectItem>
                <SelectItem value="High">High (Luxury & Premium)</SelectItem>
              </SelectContent>
            </Select>
            {fieldErrors?.budget && <p className="text-sm text-destructive">{fieldErrors.budget.join(', ')}</p>}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="country" className="font-medium text-foreground/90 flex items-center">
                <MapPin className="mr-1.5 h-4 w-4 text-foreground/70" /> Preferred Country (Optional)
              </Label>
              <Input 
                id="country" 
                name="country" 
                placeholder="e.g., Portugal, Japan" 
                className="bg-background/70 border-input focus:border-primary"
                defaultValue={initialState?.originalPreferences?.country || ""}
              />
               {fieldErrors?.country && <p className="text-sm text-destructive">{fieldErrors.country.join(', ')}</p>}
            </div>

            <div className="space-y-2">
              <Label htmlFor="city" className="font-medium text-foreground/90 flex items-center">
                 <Building className="mr-1.5 h-4 w-4 text-foreground/70" /> Preferred City/Region (Optional)
              </Label>
              <Input 
                id="city" 
                name="city" 
                placeholder="e.g., Lisbon, Kyoto Prefecture" 
                className="bg-background/70 border-input focus:border-primary"
                defaultValue={initialState?.originalPreferences?.city || ""}
              />
              {fieldErrors?.city && <p className="text-sm text-destructive">{fieldErrors.city.join(', ')}</p>}
            </div>
          </div>
           <p className="text-xs text-muted-foreground">
              Providing a country or city helps WanderGenie find offbeat places near areas you're interested in.
            </p>
        </CardContent>
        <CardFooter>
          <SubmitButton disabled={isSubmitting} />
        </CardFooter>
      </form>
    </Card>
  );
}
