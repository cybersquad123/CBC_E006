// src/components/wander-genie/TravelPlanOptionsDisplay.tsx
"use client";

import type { FormEvent } from 'react';
import { useFormStatus } from 'react-dom';
import type { TravelPlanOption } from '@/ai/flows/generate-travel-plan-options';
import type { OriginalPreferences, ElaborationFormState } from '@/app/actions';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ThumbsUp, Zap, Star, MessageSquare } from 'lucide-react'; 
import { Badge } from '@/components/ui/badge';


interface TravelPlanOptionsDisplayProps {
  options: TravelPlanOption[];
  originalPreferences: OriginalPreferences;
  elaborationFormAction: (payload: FormData) => void;
  elaborationState: ElaborationFormState; 
  isElaboratingAny: boolean; 
  setSelectedPlanIdToElaborate: (id: string | null) => void; 
  selectedPlanIdBeingElaborated: string | null;
}

function ElaborateSubmitButton({ planId, isElaboratingAny, selectedPlanIdBeingElaborated }: { planId: string, isElaboratingAny: boolean, selectedPlanIdBeingElaborated: string | null }) {
  const { pending } = useFormStatus();
  const isThisButtonPending = pending && selectedPlanIdBeingElaborated === planId;
  const isDisabled = isElaboratingAny || pending;


  return (
    <Button 
      type="submit" 
      disabled={isDisabled} 
      className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
      variant="default"
      size="lg"
    >
      {isThisButtonPending ? (
        <>
          <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          Crafting Details...
        </>
      ) : (
        <>
          <ThumbsUp className="mr-2 h-5 w-5" />
          Choose & Get Full Itinerary
        </>
      )}
    </Button>
  );
}

const RenderStars = ({ rating, reviewCount }: { rating?: number; reviewCount?: number }) => {
  if (typeof rating !== 'number') {
    return <Badge variant="outline" className="text-xs">No rating</Badge>;
  }

  const fullStars = Math.floor(rating);
  const halfStar = rating % 1 >= 0.25 && rating % 1 < 0.75; 
  const almostFullStar = rating % 1 >= 0.75; 
  const actualFullStars = fullStars + (almostFullStar ? 1 : 0);
  
  const displayRating = rating.toFixed(1);

  return (
    <div className="flex items-center gap-1">
      <div className="flex">
        {[...Array(actualFullStars)].map((_, i) => (
          <Star key={`full-${i}`} className="h-4 w-4 text-yellow-400 fill-yellow-400" />
        ))}
        {halfStar && (
          <Star key="half" className="h-4 w-4 text-yellow-400 fill-yellow-200" />
        )}
        {[...Array(5 - actualFullStars - (halfStar ? 1 : 0))].map((_, i) => (
          <Star key={`empty-${i}`} className="h-4 w-4 text-gray-300" />
        ))}
      </div>
      <Badge variant="secondary" className="text-xs">
        {displayRating}
      </Badge>
      {typeof reviewCount === 'number' && (
        <div className="flex items-center text-xs text-muted-foreground ml-1">
          <MessageSquare className="h-3 w-3 mr-0.5" /> ({reviewCount})
        </div>
      )}
    </div>
  );
};


export function TravelPlanOptionsDisplay({ 
  options, 
  originalPreferences, 
  elaborationFormAction,
  elaborationState,
  isElaboratingAny,
  setSelectedPlanIdToElaborate,
  selectedPlanIdBeingElaborated
}: TravelPlanOptionsDisplayProps) {

  const handleSubmit = (event: FormEvent<HTMLFormElement>, planId: string) => {
    setSelectedPlanIdToElaborate(planId);
  };

  return (
    <div className="space-y-8">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-primary flex items-center justify-center">
          <Zap className="mr-3 h-8 w-8" />
          Your Adventure Blueprints!
        </h2>
        <p className="text-lg text-foreground/80 mt-2 max-w-2xl mx-auto">
          Here are unique travel ideas crafted for you, sorted by rating. Pick your favorite!
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {options.map((option) => (
          <Card key={option.id} className="shadow-lg border border-primary/10 flex flex-col hover:shadow-xl transition-shadow duration-300 bg-card">
            <CardHeader className="pb-3">
              <CardTitle className="text-xl font-semibold text-primary">{option.title}</CardTitle>
              <div className="mt-1.5">
                <RenderStars rating={option.rating} reviewCount={option.reviewCount} />
              </div>
            </CardHeader>
            <CardContent className="flex-grow pt-0 pb-4">
              <ScrollArea className="h-[100px] pr-2">
                <p className="text-sm text-card-foreground/90 leading-relaxed">{option.briefDescription}</p>
              </ScrollArea>
               {option.ratingSource && (
                <p className="text-xs text-muted-foreground mt-2">
                  Rating source (mock): <a href={option.ratingSource} target="_blank" rel="noopener noreferrer" className="underline hover:text-accent transition-colors">{new URL(option.ratingSource).hostname}</a>
                </p>
              )}
            </CardContent>
            <CardFooter>
              <form action={elaborationFormAction} onSubmit={(e) => handleSubmit(e, option.id)} className="w-full">
                <input type="hidden" name="selectedPlanId" value={option.id} />
                <input type="hidden" name="selectedPlanTitle" value={option.title} />
                <input type="hidden" name="selectedPlanBriefDescription" value={option.briefDescription} />
                
                <input type="hidden" name="originalDuration" value={originalPreferences.duration} />
                <input type="hidden" name="originalInterests" value={originalPreferences.interests} />
                {originalPreferences.foodPreference && <input type="hidden" name="originalFoodPreference" value={originalPreferences.foodPreference} />}
                <input type="hidden" name="originalBudget" value={originalPreferences.budget} />
                {originalPreferences.country && <input type="hidden" name="originalCountry" value={originalPreferences.country} />}
                {originalPreferences.city && <input type="hidden" name="originalCity" value={originalPreferences.city} />}
                
                <ElaborateSubmitButton 
                  planId={option.id}
                  isElaboratingAny={isElaboratingAny} 
                  selectedPlanIdBeingElaborated={selectedPlanIdBeingElaborated}
                />
              </form>
            </CardFooter>
             {elaborationState?.status === 'error' && selectedPlanIdBeingElaborated === option.id && (
              <p className="text-xs text-destructive p-2 text-center">{elaborationState.error}</p>
            )}
          </Card>
        ))}
      </div>
       {options.length === 0 && (
         <Card className="shadow-lg border border-primary/10 flex flex-col items-center justify-center p-10 min-h-[200px]">
            <CardTitle className="text-xl font-semibold text-primary mb-2">No Adventure Options Found</CardTitle>
            <CardDescription className="text-center text-foreground/80">
                WanderGenie couldn't find any specific adventure options based on your current preferences. <br/>
                Try adjusting your interests, duration, or budget and search again!
            </CardDescription>
         </Card>
       )}
    </div>
  );
}
