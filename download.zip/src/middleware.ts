
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// This function can be marked `async` if using `await` inside
export function middleware(request: NextRequest) {
  const currentUserCookie = request.cookies.get('firebaseAuthToken'); // Example cookie name, adjust as needed
  const { pathname } = request.nextUrl;

  // Allow access to static files and Next.js internals
  if (pathname.startsWith('/_next/') || pathname.startsWith('/static/') || pathname.includes('.')) {
    return NextResponse.next();
  }
  
  const isAuthenticated = !!currentUserCookie; // Simplified check

  // Public routes that don't require authentication
  const publicPaths = ['/login', '/'];

  if (publicPaths.includes(pathname)) {
    // If user is authenticated and tries to access login, redirect to planner
    if (isAuthenticated && pathname === '/login') {
      return NextResponse.redirect(new URL('/planner', request.url));
    }
    return NextResponse.next();
  }

  // Protected routes
  if (pathname.startsWith('/planner')) {
    if (!isAuthenticated) {
      // If not authenticated, redirect to login page, preserving the intended path
      const loginUrl = new URL('/login', request.url);
      loginUrl.searchParams.set('redirect', pathname);
      return NextResponse.redirect(loginUrl);
    }
  }

  return NextResponse.next();
}

// See "Matching Paths" below to learn more
export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next/static (static files)
     * - _next/image (image optimization files)
     * - favicon.ico (favicon file)
     */
    '/((?!api|_next/static|_next/image|favicon.ico).*)',
  ],
};
